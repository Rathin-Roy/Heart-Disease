<?php 
session_start();
$age = $_POST['age'];
$sex = $_POST['sex'];
$cp = $_POST['cp'];
$trestbps = $_POST['trestbps'];
$chol = $_POST['chol'];
$fbs = $_POST['fbs'];
$restecg = $_POST['restecg'];
$thalach = $_POST['thalach'];
$exang = $_POST['exang'];
$oldpeak = $_POST['oldpeak'];
$slope = $_POST['slope'];
$ca = $_POST['ca'];
$thal = $_POST['thal'];
$target = $_POST['target'];

$db = mysqli_connect('localhost', 'root', '', 'rathin');

$count = "SELECT COUNT(*) FROM `heartattack` WHERE `COL 1`='$age' AND `COL 2`='$sex' AND `COL 3`='$cp' AND `COL 4`='$trestbps' AND `COL 5`='$chol' AND `COL 6`='$fbs' AND `COL 7`='$restecg' AND `COL 8`='$thalach' AND `COL 9`='$exang' AND `COL 10`='$oldpeak' AND `COL 11`='$slope' AND `COL 12`='$ca' AND `COL 13`='$thal' AND `COL 14`='$target'";
$implement = mysqli_query($db, $count);
$assoc = mysqli_fetch_assoc($implement);

if($assoc['COUNT(*)']==1){
    $_SESSION['success'] = "This Person has HeartDisease";
    // header('location: index.php');
}
else{
    $_SESSION['error'] = "This Person has not HeartDisease";
    // header('location: index.php');    

}
// print_r($assoc['COUNT(*)']);
?>