<?php session_start()?>
<!doctype html>
<h? lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <form action="target_post.php" method="post">
                    <div class="card">
                        <div class="card-header"></div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label col-form-label-sm">Email</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="age">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Sex</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="sex">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Cp</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="cp">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Trestbps</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="trestbps">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">chol</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="chol">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">fbs</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="fbs">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">restecg</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="restecg">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">thalach</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="thalach">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Exang</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="exang">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Oldpeak</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="oldpeak">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Slope</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="slope">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Ca</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="ca">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Thal</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="thal">
                                </div>
                                <label class="col-sm-2 col-form-label col-form-label-sm">Target</label>
                                <div class="col-sm-10 mt-3">
                                    <input type="text" class="form-control form-control-sm" plac name="target">
                                </div>

                                <?php if(isset($_SESSION['success'])){?>
                                    <div class="alert alert-success">
                                        <?php echo $_SESSION['success'];?>
                                    </div>
                                <?php } ?>
                                <?php if(isset($_SESSION['error'])){?>
                                    <div class="alert alert-success">
                                        <?php echo $_SESSION['error'];?>
                                    </div>
                                <?php } ?>
                                <button class="btn btn-primary" type="submit">Cheak</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</h?>

<?php session_unset()?>